Thank you for downloading ServerBrowse, we hope you this project.

How to setup SB?
----------------

Unpack this RAR onto your server, you will need a server with PHP 4 or 5.

Once unpacked please review the settings in the config file at: ServerBrowse/config/main_config.php

The system should now be functional, have a good time with it!!

So... What next?
----------------

Please goto our forums and submit your ideas/comments so we can make SB even more useful and powerful, alternatively you may wish to tinker with the code, please visit our "SVN" section of the website for instructions on how to fetch the source code and submit "patches".
