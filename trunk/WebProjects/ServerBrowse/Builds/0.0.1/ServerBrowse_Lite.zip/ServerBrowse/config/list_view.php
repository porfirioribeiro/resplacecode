<?php
//config for the displaying of "list view".



?>