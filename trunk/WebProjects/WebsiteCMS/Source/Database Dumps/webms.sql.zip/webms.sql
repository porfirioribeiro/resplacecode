-- phpMyAdmin SQL Dump
-- version 2.9.0-beta1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 11, 2007 at 03:11 PM
-- Server version: 5.0.18
-- PHP Version: 5.2.3
-- 
-- Database: `webms`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `webms_users`
-- 

CREATE TABLE `webms_users` (
  `id` int(1) NOT NULL auto_increment,
  `usrname` varchar(16) NOT NULL,
  `psswrd` varchar(160) NOT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(16) NOT NULL,
  `usrlvl` smallint(1) NOT NULL default '1',
  `datereg` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `datelog` timestamp NOT NULL default '0000-00-00 00:00:00',
  `sig` text NOT NULL,
  `avatar` varchar(12) NOT NULL,
  `activate` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;
