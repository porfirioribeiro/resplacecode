-- phpMyAdmin SQL Dump
-- version 2.9.0-beta1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Aug 05, 2007 at 11:57 PM
-- Server version: 5.0.18
-- PHP Version: 5.2.3
-- 
-- Database: `WebMS`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `webms_users`
-- 

CREATE TABLE `webms_users` (
  `id` int(1) NOT NULL auto_increment,
  `usrname` varchar(16) NOT NULL,
  `psswrd` varchar(16) NOT NULL,
  `email` varchar(20) NOT NULL,
  `name` varchar(16) NOT NULL,
  `usrlvl` smallint(1) NOT NULL default '0',
  `datereg` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `datelog` timestamp NOT NULL default '0000-00-00 00:00:00',
  `sig` text NOT NULL,
  `avatar` varchar(12) NOT NULL,
  `activate` tinyint(1) NOT NULL,
  `activatestring` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `webms_users`
-- 

INSERT INTO `webms_users` (`id`, `usrname`, `psswrd`, `email`, `name`, `usrlvl`, `datereg`, `datelog`, `sig`, `avatar`, `activate`, `activatestring`) VALUES 
(3, 'deano', 'playing', 'dt_8792@yahoo.co.uk', 'deano', 0, '2007-08-05 18:51:21', '0000-00-00 00:00:00', '', '', 1, '');
